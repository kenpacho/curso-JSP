create definer = charly@`%` view ART_DEPORTES as
select `sqltutorial`.`PRODUCTOS`.`NOMBRE_ARTÍCULO` AS `NOMBRE_ARTÍCULO`,
       `sqltutorial`.`PRODUCTOS`.`SECCIÓN`         AS `SECCIÓN`,
       `sqltutorial`.`PRODUCTOS`.`PRECIO`          AS `PRECIO`,
       `sqltutorial`.`PRODUCTOS`.`PAÍS_DE_ORIGEN`  AS `PAÍS_DE_ORIGEN`
from `sqltutorial`.`PRODUCTOS`
where (`sqltutorial`.`PRODUCTOS`.`PAÍS_DE_ORIGEN` = 'ESPAÑA');


create definer = charly@`%` trigger REVISA_PRECIO
    before update
    on PRODUCTOS
    for each row
BEGIN
        IF(NEW.PRECIO <0) THEN
            SET NEW.PRECIO=OLD;
        ELSEIF(NEW.PRECIO>1000) THEN
            SET NEW.PRECIO=OLD;
        END IF;

    END;


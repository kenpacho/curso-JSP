create
    definer = charly@`%` procedure MUESTRACLIENTES()
SELECT * FROM CLIENTES WHERE POBLACIÓN ='MADRID';

